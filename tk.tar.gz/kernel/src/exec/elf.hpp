#ifndef ELF_HPP
#define ELF_HPP 1

#include <cstddef>
#include <cstdint>

struct Elf64_Ehdr {
    uint8_t  e_ident[16];
    uint16_t e_type;
    uint16_t e_machine;
    uint32_t e_version;
    uint64_t e_entry;
    uint64_t e_phoff;
    uint64_t e_shoff;
    uint32_t e_flags;
    uint16_t e_ehsize;
    uint16_t e_phentsize;
    uint16_t e_phnum;
    uint16_t e_shentsize;
    uint16_t e_shnum;
    uint16_t e_shstrndx;
};

struct Elf64_Phdr {
    uint32_t p_type;
    uint32_t p_flags;
    uint64_t p_offset;
    uint64_t p_vaddr;
    uint64_t p_paddr;
    uint64_t p_filesz;
    uint64_t p_memsz;
    uint64_t p_align;
};

struct Elf64_Shdr {
    uint32_t sh_name;
    uint32_t sh_type;
    uint64_t sh_flags;
    uint64_t sh_addr;
    uint64_t sh_offset;
    uint64_t sh_size;
    uint32_t sh_link;
    uint32_t sh_info;
    uint64_t sh_addralign;
    uint64_t sh_entsize;
};

struct Elf64_Sym {
    uint32_t st_name;
    unsigned char st_info;
    unsigned char st_other;
    uint16_t st_shndx;
    uint64_t st_value;
    uint64_t st_size;
};

struct Elf64_Dyn {
    int64_t  d_tag;
    uint64_t d_val;
};

struct Elf64_Rela {
    uint64_t r_offset;
    uint64_t r_info;
    int64_t  r_addend;
};

struct Elf64_Rel {
    uint64_t r_offset;
    uint64_t r_info;
};

void run_elf(void* base, size_t filesz, bool user, const char* argv[], const char* envp[]);
void* get_elf_entry_point_user(void* elf_base, size_t elf_file_size, void* stack_top = nullptr, void** ret_stack_top = nullptr);

void* stack_manager_get_new_stack(size_t num_pages = 2, bool user = true);
bool destroy_stack(void* stack_top);

struct proc_address_space {
    void* base;
    size_t total_size;
    
    void* code_base;
    size_t code_size;
    
    void* data_base;
    size_t data_size;

    void* extra_base;
    size_t extra_size;
    
    void* heap_base;
    size_t heap_size;
    
    void* stack_base;
    size_t stack_size;
    
    size_t num_pages;
};

proc_address_space* load_elf(void* base, size_t filesz, bool user, const char* argv[], const char* envp[]);
void exec_elf(proc_address_space* addr_space, void* base, size_t filesz, bool user, const char* argv[], const char* envp[]);
void* get_elf_entry_point_user(proc_address_space* addr_space, void* base, size_t filesz, bool user, const char* argv[], const char* envp[], void** out_stack);
void free_addr_space(proc_address_space* addr_space);

#endif
